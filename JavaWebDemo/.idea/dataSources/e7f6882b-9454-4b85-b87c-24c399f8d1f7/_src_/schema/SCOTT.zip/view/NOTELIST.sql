CREATE VIEW NOTELIST AS SELECT
    note.noteId,
    note.noteNumber,
    note.noteName,
    note.noteType,
    note.noteOwner,
    note.noteTime,
    usernote.userId,
    usernote.content,
    "user".userName,
    countab.ncount
  FROM
    note,
    usernote,
    "user",
    (SELECT
       note.noteId,
       COUNT(*) ncount
     FROM
       note,
       usernote,
       "user"
     WHERE
       note.noteId = usernote.noteId
       AND "user".userId = usernote.userId
       AND usernote.floorNumber = 1
     GROUP BY note.noteId) countab
  WHERE
    note.noteId = usernote.noteId
    AND "user".userId = usernote.userId
    AND usernote.floorNumber = 1
    AND countab.noteId = note.noteId
  ORDER BY note.noteTime DESC
/
