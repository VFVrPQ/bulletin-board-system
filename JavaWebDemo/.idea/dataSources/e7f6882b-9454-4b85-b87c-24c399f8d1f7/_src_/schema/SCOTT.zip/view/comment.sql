CREATE VIEW "comment" AS SELECT
    usernote.noteId,
    usernote.userId,
    usernote.floorNumber,
    usernote.content,
    usernote.floorType,
    usernote.floorTime,
    "user".userName
  FROM
    usernote,
    "user"
  WHERE
    usernote.userId = "user".userId
    AND usernote.floorNumber != 1
  ORDER BY floorNumber DESC
/
