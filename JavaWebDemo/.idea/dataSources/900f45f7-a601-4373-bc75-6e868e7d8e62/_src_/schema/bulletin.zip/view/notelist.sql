CREATE VIEW notelist AS
  SELECT
    `bulletin`.`note`.`noteId`      AS `noteId`,
    `bulletin`.`note`.`noteNumber`  AS `noteNumber`,
    `bulletin`.`note`.`noteName`    AS `noteName`,
    `bulletin`.`note`.`noteType`    AS `noteType`,
    `bulletin`.`note`.`noteOwner`   AS `noteOwner`,
    `bulletin`.`note`.`noteTime`    AS `noteTime`,
    `bulletin`.`usernote`.`userId`  AS `userId`,
    `bulletin`.`usernote`.`content` AS `content`,
    `bulletin`.`user`.`userName`    AS `userName`,
    count(0)                        AS `number`
  FROM ((`bulletin`.`note`
    JOIN `bulletin`.`usernote`) JOIN `bulletin`.`user`)
  WHERE ((`bulletin`.`note`.`noteId` = `bulletin`.`usernote`.`noteId`) AND
         (`bulletin`.`user`.`userId` = `bulletin`.`usernote`.`userId`) AND (`bulletin`.`usernote`.`floorNumber` = 1))
  GROUP BY `bulletin`.`note`.`noteId`
  ORDER BY `bulletin`.`note`.`noteTime` DESC;
