CREATE VIEW comment AS
  SELECT
    `bulletin`.`usernote`.`noteId`      AS `noteId`,
    `bulletin`.`usernote`.`userId`      AS `userId`,
    `bulletin`.`usernote`.`floorNumber` AS `floorNumber`,
    `bulletin`.`usernote`.`content`     AS `content`,
    `bulletin`.`usernote`.`floorType`   AS `floorType`,
    `bulletin`.`usernote`.`floorTime`   AS `floorTime`,
    `bulletin`.`user`.`userName`        AS `userName`
  FROM (`bulletin`.`usernote`
    JOIN `bulletin`.`user`)
  WHERE ((`bulletin`.`usernote`.`userId` = `bulletin`.`user`.`userId`) AND (`bulletin`.`usernote`.`floorNumber` <> 1))
  GROUP BY `bulletin`.`usernote`.`noteId`, `bulletin`.`usernote`.`floorNumber`
  ORDER BY `bulletin`.`usernote`.`floorNumber` DESC;
